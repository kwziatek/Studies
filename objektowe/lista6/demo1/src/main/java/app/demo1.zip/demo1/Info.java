package app.demo1;

import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.MenuItem;

public class Info extends MenuItem {
    public Info(){
        super("Info");
        initialize();
    }
    private void initialize(){
        setOnAction(e -> {
            // Tworzenie okienka dialogowego typu Alert
            Alert alert = new Alert(Alert.AlertType.INFORMATION);
            alert.setTitle("Info");
            alert.setHeaderText("Info");
            alert.setContentText("Project name: Graphic editor \nAuthor: Karol Wziątek\nPurpose: Project was created for OOP course to be graded \nFunctionality: Geometric figures drawing, adjusting their colour and size, rotating them, saving them to a file and loading back");

            alert.showAndWait().ifPresent(response -> {
                if (response == javafx.scene.control.ButtonType.OK) {
                    alert.close();
                }
            });
        });
    }

}
